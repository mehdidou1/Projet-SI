import os
import django


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Gestion_Rh.settings') 
django.setup()

from GestioRH.models import Fonctionnalite  

def ajouter_fonctionnalites():
    fonctionnalites = [
        "Absences",
        "Retards",
        "Gestion des Employés",
        "Congés",
        "Type de Congé",
        "Soldes de Congé",
        "Contrats",
        "Salaires",
        "Recrutement",
        "Évaluations",
        "Fiches de Paie",
        "Primes",
        "Fiches Employés",
        "Services",
        "Types de Contrat",
        "Liste des Entretiens",
        "Liste des Candidats",
        "Archive de Contrats",
        "Boîte de Réception"

    ]

    for nom in fonctionnalites:
        Fonctionnalite.objects.create(nom=nom)
        print(f"Fonctionnalité ajoutée : {nom}")

if __name__ == "__main__":
    ajouter_fonctionnalites()