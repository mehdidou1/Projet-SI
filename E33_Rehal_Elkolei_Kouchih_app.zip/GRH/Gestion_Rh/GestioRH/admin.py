from django.contrib import admin
from GestioRH.models import Employe , Service
# Register your models here.

admin.site.register(Employe)
admin.site.register(Service)
 

