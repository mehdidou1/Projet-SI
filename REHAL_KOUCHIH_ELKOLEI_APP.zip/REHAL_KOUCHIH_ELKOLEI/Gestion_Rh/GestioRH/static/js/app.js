document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour récupérer et afficher la liste des employés
    function fetchEmployes() {
        fetch('/api/employes/')
            .then(response => response.json())
            .then(data => {
                const employeList = document.getElementById('employe-list');
                employeList.innerHTML = ''; // Réinitialiser la liste
                data.forEach(employe => {
                    const div = document.createElement('div');
                    div.innerHTML = `
                        <strong>${employe.nom} ${employe.prenom}</strong> - ${employe.sexe} - ${employe.date_naissance} - ${employe.date_embauche} 
                        <button onclick="deleteEmploye(${employe.id})">Supprimer</button>
                        <button onclick="populateUpdateForm(${employe.id})">Modifier</button>
                    `;
                    employeList.appendChild(div);
                });
            })
            .catch(error => console.error('Erreur:', error));
    }

    // Appel initial pour charger les employés
    fetchEmployes();

    // Soumission du formulaire pour ajouter un nouvel employé
    const employeForm = document.getElementById('employe-form');
    if (employeForm) {
        employeForm.addEventListener('submit', function(event) {
            event.preventDefault(); 
            const formData = new FormData(employeForm);
            fetch('/api/employes/', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                console.log('Employé ajouté:', data);
                fetchEmployes(); // Mettre à jour la liste des employés
                employeForm.reset(); // Réinitialiser le formulaire
            })
            .catch(error => console.error('Erreur:', error));
        });
    }

    // Soumission du formulaire pour mettre à jour un employé
    const updateEmployeForm = document.getElementById('update-employe-form');
    if (updateEmployeForm) {
        updateEmployeForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(updateEmployeForm);
            const id = formData.get('id');
            fetch(`/api/employes/${id}/`, {
                method: 'PUT',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                console.log('Employé mis à jour:', data);
                fetchEmployes(); // Mettre à jour la liste des employés
                updateEmployeForm.reset(); // Réinitialiser le formulaire
            })
            .catch(error => console.error('Erreur:', error));
        });
    }

    // Fonction pour supprimer un employé
    window.deleteEmploye = function(id) {
        fetch(`/api/employes/${id}/`, {
            method: 'DELETE',
        })
        .then(response => {
            if (response.ok) {
                console.log('Employé supprimé');
                fetchEmployes(); // Mettre à jour la liste des employés
            } else {
                console.error('Erreur lors de la suppression de l\'employé');
            }
        })
        .catch(error => console.error('Erreur:', error));
    };

    // Fonction pour pré-remplir le formulaire de mise à jour
    window.populateUpdateForm = function(id) {
        fetch(`/api/employes/${id}/`)
            .then(response => response.json())
            .then(data => {
                const updateForm = document.getElementById('update-employe-form');
                updateForm.elements['id'].value = data.id;
                updateForm.elements['nom'].value = data.nom;
                updateForm.elements['prenom'].value = data.prenom;
                updateForm.elements['sexe'].value = data.sexe;
                updateForm.elements['date_naissance'].value = data.date_naissance;
                updateForm.elements['date_embauche'].value = data.date_embauche;
            })
            .catch(error => console.error('Erreur:', error));
    };

    // Fonction pour gérer les types de congés
    function fetchTypeConges() {
        fetch('/api/type_conges/')
            .then(response => response.json())
            .then(data => {
                const typeCongeList = document.getElementById('type-conge-list');
                typeCongeList.innerHTML = ''; // Réinitialiser la liste
                data.forEach(typeConge => {
                    const div = document.createElement('div');
                    div.innerHTML = `<strong>${typeConge.nom}</strong> <button onclick="deleteTypeConge(${typeConge.id})">Supprimer </button>`;
                    typeCongeList.appendChild(div);
                });
            })
            .catch(error => console.error('Erreur:', error));
    }

    // Appel initial pour charger les types de congés
    fetchTypeConges();

    // Soumission du formulaire pour ajouter un nouveau type de congé
    const typeCongeForm = document.getElementById('type-conge-form');
    if (typeCongeForm) {
        typeCongeForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Empêcher le rechargement de la page
            const formData = new FormData(typeCongeForm);
            fetch('/api/type_conges/', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                console.log('Type de congé ajouté:', data);
                fetchTypeConges(); // Mettre à jour la liste des types de congés
                typeCongeForm.reset(); // Réinitialiser le formulaire
            })
            .catch(error => console.error('Erreur:', error));
    },

    // Fonction pour supprimer un type de congé
    window.deleteTypeConge = function(id) {
        fetch(`/api/type_conges/${id}/`, {
            method: 'DELETE',
        })
        .then(response => {
            if (response.ok) {
                console.log('Type de congé supprimé');
                fetchTypeConges(); // Mettre à jour la liste des types de congés
            } else {
                console.error('Erreur lors de la suppression du type de congé');
            }
        })
        .catch(error => console.error('Erreur:', error));
    },

    // Fonction pour gérer les contrats
    function fetchContrats() {
        fetch('/api/contrats/')
            .then(response => response.json())
            .then(data => {
                const contratList = document.getElementById('contrat-list');
                contratList.innerHTML = ''; // Réinitialiser la liste
                data.forEach(contrat => {
                    const div = document.createElement('div');
                    div.innerHTML = `<strong>${contrat.type}</strong> <button onclick="deleteContrat(${contrat.id})">Supprimer</button>`;
                    contratList.appendChild(div);
                });
            })
            .catch(error => console.error('Erreur:', error));
    }

    // Appel initial pour charger les contrats
    fetchContrats(),

    // Soumission du formulaire pour ajouter un nouveau contrat
    const contratForm = document.getElementById('contrat-form');
    if (contratForm) {
        contratForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Empêcher le rechargement de la page
            const formData = new FormData(contratForm);
            fetch('/api/contrats/', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                console.log('Contrat ajouté:', data);
                fetchContrats(); // Mettre à jour la liste des contrats
                contratForm.reset(); // Réinitialiser le formulaire
            })
            .catch(error => console.error('Erreur:', error));
        });
    }

    // Fonction pour supprimer un contrat
    window.deleteContrat = function(id) {
        fetch(`/api/contrats/${id}/`, {
            method: 'DELETE',
        })
        .then(response => {
            if (response.ok) {
                console.log('Contrat supprimé');
                fetchContrats(); // Mettre à jour la liste des contrats
            } else {
                console.error('Erreur lors de la suppression du contrat');
            }
        })
        .catch(error => console.error('Erreur:', error));
    };

    // Fonction pour gérer les salaires
    function fetchSalaires() {
        fetch('/api/salaires/')
            .then(response => response.json())
            .then(data => {
                const salaireList = document.getElementById('salaire-list');
                salaireList.innerHTML = ''; // Réinitialiser la liste
                data.forEach(salaire => {
                    const div = document.createElement('div');
                    div.innerHTML = `<strong>${salaire.montant} €</strong> <button onclick="deleteSalaire(${salaire.id})">Supprimer</button>`;
                    salaireList.appendChild(div);
                });
            })
            .catch(error => console.error('Erreur:', error));
    }

    // Appel initial pour charger les salaires
    fetchSalaires();

    // Soumission du formulaire pour ajouter un nouveau salaire
    const salaireForm = document.getElementById('salaire-form');
    if (salaireForm) {
        salaireForm.addEventListener(' submit', function(event) {
            event.preventDefault(); // Empêcher le rechargement de la page
            const formData = new FormData(salaireForm);
            fetch('/api/salaires/', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                console.log('Salaire ajouté:', data);
                fetchSalaires(); // Mettre à jour la liste des salaires
                salaireForm.reset(); // Réinitialiser le formulaire
            })
            .catch(error => console.error('Erreur:', error));
        });
    }

    // Fonction pour supprimer un salaire
    window.deleteSalaire = function(id) {
        fetch(`/api/salaires/${id}/`, {
            method: 'DELETE',
        })
        .then(response => {
            if (response.ok) {
                console.log('Salaire supprimé');
                fetchSalaires(); // Mettre à jour la liste des salaires
            } else {
                console.error('Erreur lors de la suppression du salaire');
            }
        })
        .catch(error => console.error('Erreur:', error));
    };
});