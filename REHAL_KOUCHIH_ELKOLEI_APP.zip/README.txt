!!! Des hyperliens ont été intégrés dans notre rapport. Il est donc recommandé de l'ouvrir avec Adobe Acrobat pour une meilleure expérience de lecture. !!!


# GestioRH

Une application Django pour la gestion des Ressources Humaines (RH) d’une Entreprise.

## Prérequis

Avant de commencer, assurez-vous que vous avez installé les éléments suivants :

- Python 3.x
- Django 3.x ou supérieur
- PostgreSQL (ou une autre base de données compatible)
- pip (gestionnaire de paquets Python)

## Installation

### 1. Clonez le dépôt

```bash
git clone https://github.com/votre-utilisateur/entreprise-gestion.git
cd entreprise-gestion
```

### 2. Créez un environnement virtuel

```bash
python -m venv venv
source venv/bin/activate  # Sur Linux/Mac
venv\Scripts ctivate  # Sur Windows
```

### 3. Installez les dépendances

```bash
pip install -r requirements.txt
```

### 4. Configuration de la base de données

- Créez une base de données dans PostgreSQL.
- Modifiez le fichier `settings.py` pour y indiquer vos informations de connexion à la base de données.

### 5. Appliquez les migrations

```bash
python manage.py migrate
```

### 6. Créez un superutilisateur pour l'admin

```bash
python manage.py createsuperuser
```

### 7. Lancez le serveur

```bash
python manage.py runserver
```

Accédez à l'application sur `http://127.0.0.1:8000/`.


## Bibliothèques Standards

- **calendar** : Fournit des fonctions liées aux calendriers, permettant d'afficher des vues mensuelles ou annuelles.
- **datetime** : Utilisé pour manipuler les dates et les heures, y compris l'obtention de la date actuelle et la gestion des fuseaux horaires.
- **json** : Facilite l'encodage et le décodage des données JSON, utile pour les réponses API.
- **random** : Génère des nombres aléatoires, utilisé ici pour créer des codes de confirmation.

## Bibliothèques Django

- **django.views.generic.dates** : Contient des vues basées sur des classes pour afficher des archives de données par mois, jour ou année, utiles pour organiser les événements liés aux RH.
- **django.db.models.functions** : Fournit des fonctions pour manipuler les requêtes de base de données. TruncMonth aide à regrouper les données par mois.
- **django.contrib.auth** : Gère l'authentification des utilisateurs, y compris la connexion et les vérifications de permission.
- **django.core.mail** : Permet d'envoyer des e-mails, comme les e-mails de confirmation lors de l'inscription d'un utilisateur.
- **django.http** : Inclut des utilitaires pour les réponses HTTP, comme JsonResponse pour retourner des données JSON.
- **django.db.models** : Fournit des fonctionnalités ORM pour interagir avec la base de données, permettant des requêtes complexes comme le comptage d'employés ou le filtrage d'enregistrements.
- **django.contrib.messages** : Utilisé pour afficher des messages aux utilisateurs (par exemple, notifications de succès ou d'erreur).
- **django.shortcuts** : Contient des fonctions utilitaires pour rendre des modèles et rediriger les utilisateurs.
- **django.db.models.signals import post_save** : Est un signal fourni par Django qui est émis après qu'un objet a été enregistré dans la base de données. Cela inclut les opérations de création et de mise à jour d'un modèle.
- **django.dispatch import receiver** : En utilisant ce décorateur pour créer des fonctions qui réagissent à des événements spécifiques dans l'application, comme envoyer une notification chaque fois qu'un nouvel employé est ajouté à la base de données.
- **django.core.exceptions import ValidationError** : Cette importation permet d'utiliser l'exception ValidationError, qui est levée lorsque les données ne respectent pas les règles de validation définies dans les formulaires ou les modèles. Cela est essentiel pour garantir l'intégrité des données et informer les utilisateurs des erreurs lors de la soumission de formulaires.
- **django.conf import settings** : Cette importation donne accès aux paramètres de configuration du projet Django. Cela permet d'accéder à des valeurs comme les paramètres d'e-mail, les configurations de base de données.
- **django.core.mail import send_mail** : send_mail cette fonction est utilisée pour envoyer des e-mails depuis l'application Django.
- **from django.core.mail import BadHeaderError** : BadHeaderError cette exception est levée lorsque les en-têtes d'un e-mail sont incorrects ou malformés. Cela permet à l'application de gérer les erreurs liées à l'envoi d'e-mails et d'éviter que des e-mails mal formés ne soient envoyés.
- **django.urls import reverse_lazy** : reverse_lazy est une fonction utilisée pour générer des URL à partir de noms de vue, mais elle est particulièrement utile dans des contextes où l'URL doit être résolue plus tard, comme dans les redirections après un traitement de formulaire.
- **django.shortcuts import get_object_or_404** : Est une fonction très utile dans Django pour simplifier la récupération d'objets tout en gérant les erreurs de manière élégante. Elle améliore la robustesse et la lisibilité du code en évitant les vérifications manuelles pour déterminer si un objet existe ou non.

## Liste des Emails et Mots de Passe

- ahmed.benali@RaD.com - EMP0001AB2010
- fatima.bensalah@HR.com - EMP0002FB2015
- karim.bouzid@Finance.com - EMP0003KB2008
- nadia.cherif@Marketing.com - EMP0004NC2018
- yacine.djemai@Sales.com - EMP0005YD2012
- leila.haddad@IT.com - EMP0006LH2016
- samir.khelifi@Logistics.com - EMP0007SK2011
- amina.mansouri@Finance.com - EMP0008AM2017
- mohamed.nacer@Marketing.com - EMP0009MN2009
- salima.ould@Sales.com - EMP0010SO2014
- sofiane.rahmani@CustomerService.com - EMP0011SR2011
- amel.saadi@HR.com - EMP0012AS2019
- rachid.touati@Logistics.com - EMP0013RT2007
- lynda.ziani@Marketing.com - EMP0014LZ2020
- nadir.ait@Sales.com - EMP0015NA2013
- nadia.belkacem@IT.com - EMP0016NB2015
- samira.chibane@HR.com - EMP0017SC2012
- karim.dali@Finance.com - EMP0018KD2008
- yasmine.elhadi@Marketing.com - EMP0019YE2016
- nabil.ferhat@Sales.com - EMP0020NF2011
- leila.gharbi@IT.com - EMP0021LG2017
- rachid.hamdi@HR.com - EMP0022RH2010
- nadia.issa@Finance.com - EMP0023NI2014
- karim.jaziri@Operations.com - EMP0024KJ2009
- amel.kaci@Sales.com - EMP0025AK2018
- samir.lounis@IT.com - EMP0026SL2012
- amina.mebarki@HR.com - EMP0027AM2016
- mohamed.nadir@Operations.com - EMP0028MN2011
- salima.ouali@Marketing.com - EMP0029SO2014
- sofiane.rahal@Sales.com - EMP0030SR2011
